num = int(input("Digite um número inteiro: "))
x = 2
for i in range(2 , num + 1, 2):
    print('{}^2 = {}'.format(i, i ** 2))
