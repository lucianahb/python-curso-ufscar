#Faça um programa que receba inicialmente um número n que determina o número de entradas dele.
#Após receber estas n entradas recebe uma outra entrada adicional contendo um número.
#Então printe o número de ocorrências deste número na lista

numEntradas = int(input("Digite um número inteiro entre 0 e 5, será o número de entradas: "))
entradaAdd = int(input("Digite um número de que será adicionado: "))


