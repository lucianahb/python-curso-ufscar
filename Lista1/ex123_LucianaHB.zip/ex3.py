print("Digite o valor de a, entre -5 e 5")
a = input()
print("Digite o valor de b, entre -5 e 5")
b = input()
print("Digite o valor de c, entre -5 e 5")
c = input()
print("Digite o valor de x, entre -5 e 5")
x = input()

a = int(a)
b = int(b)
c = int(c)
x = int(x)

expressao = (a * x ** x) + (b * x) + c

print(expressao)