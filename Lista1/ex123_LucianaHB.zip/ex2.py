#Exercício 2

print("Digite seu nome")
nome = input()
print("Digite seu sobrenome")
sobrenome = input()

print("Digite um número inteiro, de 1 a 5")
num = input()
num = int(num)

print(nome + " " + sobrenome)
print(nome * num)