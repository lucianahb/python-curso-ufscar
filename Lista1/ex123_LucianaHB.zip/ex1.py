# exercício 1

print("Digite dois números inteiros")
num1 = input()
num2 = input()

num1 = int(num1)
num2 = int(num2)


soma = num1 + num2
subtr = num1 - num2
mult = num1 * num2
div = num1 / num2
div = int(div)
pot = num1 ** num2
rest = num1 % num2

print("Soma =", soma)
print("Subtração =", subtr)
print("Multiplicação =", mult)
print("Divisão =", div)
print("Potenciação =", pot)
print("Resto =", rest)
